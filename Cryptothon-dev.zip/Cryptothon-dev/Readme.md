# Cryptothon
============

## Intro
Online event using Android App. Shows a question to a group of members of fixed sizes.
Any group member can answer the question and whole group will advance the stage.

test