package com.event.cryptothon;

public class FirebaseHelper {
    public static final boolean EMULATOR_RUNNING = true;
}
